#1

for i in range(7) :
    print("파이팅")
    
    
#더알아보기1
for k in range(1,10) :
        print(2, "x", k, "=", 2*k)
        
        
#더알아보기2
for i in range(2, 10) :
    print(i,"단")

    for k in range(1,10) :
        print(i, "x", k, "=", i*k)

    
