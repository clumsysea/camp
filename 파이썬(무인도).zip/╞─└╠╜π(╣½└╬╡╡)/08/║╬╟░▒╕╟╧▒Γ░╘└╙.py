import turtle as t
import random as r

#상어
shark = t.Turtle()
shark.shape("triangle")
shark.color("red")
shark.speed(0)
shark.penup()
shark.goto(r.randint(-200, 200), r.randint(-200, 200))

#비행기 부품
parts = t.Turtle()
parts.shape("circle")
parts.color("green")
parts.speed(0)
parts.penup()
parts.goto(r.randint(-200, 200), r.randint(-200, 200))

#암초
rock1 = t.Turtle()
rock1.shape("circle")
rock1.color("green")
rock1.speed(0)
rock1.penup()
rock1.goto(r.randint(-200, 200), r.randint(-200, 200))

rock2 = t.Turtle()
rock2.shape("circle")
rock2.color("green")
rock2.speed(0)
rock2.penup()
rock2.goto(r.randint(-200, 200), r.randint(-200, 200))


class Game() :
    # 방향 조정을 위한 메서드 
    def turn_right(self) :
        t.setheading(0)

    def turn_up(self) :
        t.setheading(90)

    def turn_left(self) :
        t.setheading(180)

    def turn_down(self) :
        t.setheading(270)

    #게임 진행을 위한 메서드 
    def play(self) :
        t.clear()
        t.forward(15)

        ang = shark.towards(t.pos())
        shark.setheading(ang)
        shark.forward(13)
        
        duration = 0
        
        if t.distance(parts) < 15 :
            self.result("부품을 찾았어요!", duration)
        elif t.distance(rock1) < 15 or t.distance(rock2) < 15 :
            duration = 1
            self.result("암초였어요.", duration)
        elif t.distance(shark) < 15 :
            self.result("다시 도전해요.", duration)
        else :
            t.ontimer(g.play,100)
            
    #결과 출력을 위한 메서드 
    def result(self, msg, dur) :
        if dur == 1 :
            t.forward(15)
            t.write(msg, False, "center", ("", 20))
        else :
            t.goto(0, 0)
            t.write(msg, False, "center", ("", 20))
            shark.goto(r.randint(-200, 200), r.randint(-200, 200))
            parts.goto(r.randint(-200, 200), r.randint(-200, 200))
            rock1.goto(r.randint(-200, 200), r.randint(-200, 200))
            rock2.goto(r.randint(-200, 200), r.randint(-200, 200))

g = Game()

#게임 배경 설정 및 진행하기
t.setup(450, 450)
t.bgcolor("skyblue")
t.shape("turtle")
t.speed(0)
t.penup()
t.goto(0, 0)
t.color("white")
t.onkeypress(g.turn_right, "Right")
t.onkeypress(g.turn_up, "Up")
t.onkeypress(g.turn_left, "Left")
t.onkeypress(g.turn_down, "Down")
t.onkeypress(g.play, "space")
t.listen()
