
import random as r

fortune = []
fortune.append("오늘은 최고의 날이예요!")
fortune.append("빨간색 물건이 행운을 가져다 줄거예요.")
fortune.append("해야할 일에 최선을 다해야 합니다.")
fortune.append("열심히 노력한 만큼의 결과를 얻을 수 있어요.")
fortune.append("방심은 금물! 어떤 일이든 침착하게 하세요.")
fortune.append("소중한 사람을 만나게 될 거예요.")
fortune.append("사랑하는 사람에게 마음을 표현하세요.")
fortune.append("오늘은 책을 읽어보세요.")
fortune.append("야외활동을 하며 날씨를 만끽하세요.")
fortune.append("부모님께 감사의 마음을 전하세요.")

print("오늘의 운세 : ", r.choice(fortune))


