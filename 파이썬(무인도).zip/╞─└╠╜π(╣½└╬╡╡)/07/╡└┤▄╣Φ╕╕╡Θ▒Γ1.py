#1
import turtle as t

#2
import turtle as t
t.forward(100)


#3
t.left(90)


#4
import turtle as t

for i in range(3) :
    t.forward(100)
    t.left(120)


#5
import turtle as t

n = 3

for i in range(n) :
    t.forward(100)
    t.left(360/n)

#6
import turtle as t

n = 3

t.pensize(3)
t.color("green")
t.fillcolor("yellow")

t.begin_fill()

for i in range(n) :
    t.forward(100)
    t.left(360/n)

t.end_fill()

