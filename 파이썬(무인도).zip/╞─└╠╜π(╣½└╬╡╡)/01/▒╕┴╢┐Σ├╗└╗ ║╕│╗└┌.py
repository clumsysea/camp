#1
print("SOS!")

#2
print("SOS!")
print("살려주세요!")


#3
print("SOS!\n살려주세요!")

