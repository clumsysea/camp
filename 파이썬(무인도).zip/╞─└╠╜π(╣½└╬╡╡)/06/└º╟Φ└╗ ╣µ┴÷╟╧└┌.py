#1

while True :
    print("어흥")
