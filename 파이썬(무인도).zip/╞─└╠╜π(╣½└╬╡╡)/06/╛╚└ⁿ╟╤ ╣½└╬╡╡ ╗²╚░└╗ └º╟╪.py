#1
pw = input("비밀번호를 입력해주세요 : ")

#2
while pw != "1234" :
    print("어흥")
    pw = input("비밀번호를 입력해주세요 : ")

#3
print("들어오세요.")



    

#더알아보기
i = 0
while i < 11 :
    i += 1
    if i % 2 != 0 :
        continue
    print(i)

    
