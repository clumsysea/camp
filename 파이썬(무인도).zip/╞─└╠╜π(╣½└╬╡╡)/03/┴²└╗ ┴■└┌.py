
#1
food = ["물", "통조림", "과일"]
things = ["나뭇가지", "진흙", "돌"]
tool = ["칼", "가위"]

#2
print(food)
print(things)
print(tool)

#3
print("음식 : ",food, "\n만들기 재료 : ", things, "\n도구 : ", tool)


#더알아보기1

string = "hello world"
cut1 = string.split()
cut2 = string.split("o")

print(cut1)
print(cut2)

#더알아보기2
string = "hello world"
part = string[1:8]
print(part)

#더알아보기3
string1 = "Hello"
string2 = "Tami"
hap1 = string1 + string2
hap2 = string1 + "," + string2
hap3 = string1*3
print(hap1)
print(hap2)
print(hap3)

#더알아보기4
string = "내가 좋아하는 숫자는 "
num = 7
print(string + str(num) + "이야.")

num1 = 2
num2= "8"

print(num1 + int(num2))

