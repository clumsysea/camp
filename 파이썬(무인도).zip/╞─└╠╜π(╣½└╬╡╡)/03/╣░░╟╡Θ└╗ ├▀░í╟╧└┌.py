
#1
food = ["물", "통조림", "과일"]
things = ["나뭇가지", "진흙", "돌"]
tool = ["칼", "가위"]

tool.append("톱")
tool.append("밧줄")
tool.append("라이터")

house = things + tool

print(tool)
print("집을 짓기 위해 필요한 물건들 : ", house)

#더알아보기1
aa = ["a", "b", "c", "d"]
print(aa[0])

#더알아보기2
aa = ["a", "b", "c", "d"]
aa.remove("b")
print(aa)

#더알아보기3
aa = ["a", "b", "c", "d"]
aa.remove(aa[1])
print(aa)

#더알아보기4
aa = ["a", "b", "c", "d"]
aa.reverse()
print("뒤집기 : ", aa)

aa.sort()
print("정렬하기 : ", aa)
