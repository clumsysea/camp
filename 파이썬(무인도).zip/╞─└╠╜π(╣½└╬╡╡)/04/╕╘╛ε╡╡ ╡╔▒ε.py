#1
days = int(input())

#2
if days > 7 :
    print("이미 상했어요.")
elif days == 7 :
    print("지금 바로 먹어야 해요.")
else :
    print("먹어도 안전해요.")




#더알아보기

height = int(input("키를 입력하세요 : "))
weight = int(input("몸무게를 입력하세요 : "))

if height >= 150 :
    if weight >= 40 :
        print("탈 수 있습니다.")
    else :
        print("몸무게가 너무 가벼워요.")

else :
    print("키가 너무 작아요.")

